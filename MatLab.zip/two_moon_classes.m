function [Px1,Px2,Mx1,Mx2] = two_moon_classes(num_points, ring_width, inner_rad)
r1 = randn([num_points,1])*ring_width/2 +inner_rad; 
theta1 = rand([num_points,1])*pi;
Px1 = r1.*cos(theta1);
Px2 = r1.*sin(theta1);

r2 = randn([num_points,1])*ring_width/2 +inner_rad; 
theta2 = rand([num_points,1])*pi+pi;
Mx1 = r2.*cos(theta2)+inner_rad;
Mx2 = r2.*sin(theta2)+inner_rad/2;
plot(Px1,Px2,'r.',Mx1,Mx2,'g.');
dataset = [[Px1 Px2 ones(num_points,1)];[Mx1 Mx2 -ones(num_points,1)]];
save('twomoon.mat','dataset');
end