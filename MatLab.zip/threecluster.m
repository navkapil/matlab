function [dataset]= threecluster(num_points, center1, center2, center3)
%threecluster(100,[-1,-1],[1,-1],[0,1])
    centers = (rand([3,2])-0.5)*5;
    
    centers(1,:) = center1;
    centers(2,:) = center2;
    centers(3,:) = center3;
    sigma = rand([3,1]);
    
    sigma = 0.2*[1,1,1]';
    X1 = randn([num_points/2,2])*sigma(1)+centers(1,:);
    X2 = randn([num_points,2])*sigma(2)+centers(2,:);
    X3 = randn([num_points/2,2])*sigma(3)+centers(3,:);
    plot(X1(:,1),X1(:,2),'r.',X2(:,1),X2(:,2),'g.',X3(:,1),X3(:,2),'k.')
    dataset = [[X1 ones(num_points/2,1)];[X2 -ones(num_points,1)];[X3 zeros(num_points/2,1)]];
    save('threecluster_lineeq.mat','dataset');
end
