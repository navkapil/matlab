function [Px1,Px2,Mx1,Mx2] = crossplane(num_points, dc1, dc2)
    Px1 = (rand(num_points,1)-0.5)*2;
    Px2 = dc1(2)/dc1(1)*Px1+(rand(num_points,1)-0.5)*0.015;
    Mx1 = (rand(num_points,1)-0.5)*2;
    Mx2 = dc2(2)/dc2(1)*Mx1+(rand(num_points,1)-0.5)*0.015;
    plot(Px1,Px2,'r.',Mx1,Mx2,'g.');
    dataset = [[Px1 Px2 ones(num_points,1)];[Mx1 Mx2 -ones(num_points,1)]];
    save('crossplanes.mat','dataset');
end