function [Yn,c,X] = create_toy_reg_cubic(num_points, SNR)

	x = randn([num_points,1]);
	x = sort(x);
	c = rand([4,1]);
	X = [x.*x.*x x.*x x ones(num_points,1)];
	y = X*c;
	Yn = y+randn([num_points,1])*SNR;
	plot(x,y,'b-',x,Yn,'r.');