clc;
clear all;
close all;
file1 = fopen('result.txt','a+');
file3 = fopen('accuracies.txt','a+');
max_trial =10;
global p1 p2;
% ep = 0.9;
            
for load_file = 2:2
    %% initializing variables
no_part=10;
    %% to load file
    switch load_file
% Add datasets here
       case 1
            file = 'aus';
            test_start =151;
        case 2
            file = 'breast-cancer-wisconsin';
            test_start =150;
        case 3
            file = 'bupa or liver-disorders';
            test_start =201;
        case 4
            file = 'cleve';
            test_start =151;
        case 5
            file = 'haberman';
            test_start =101;
        case 6
            file = 'iono';
            test_start =151;
        case 7
            file = 'pima';
            test_start = 201;
        case 8
            file = 'transfusion';
            test_start = 151;    
        case 9
            file = 'votes';
            test_start = 201;
        case 10
            file = 'wdbc';
            test_start = 101;    
        case 11
            file = 'wpbc';
            test_start = 81;
%         case 12
%             file = 'cmc';
%             test_start =201;
        case 13
            file = 'ger';
            test_start = 151;    
        case 14
            file = 'sonar';
            test_start = 201;
        case 15
            file = 'monk2';
            test_start = 101;    
        case 16
            file = 'Heart-c';
            test_start = 201;
        case 17
            file = 'heart-stat';
            test_start = 101;    
        case 18
            file = 'splice';
            test_start = 201;
        case 19
            file = 'vowel';
            test_start =201;
		case 20
            file = 'ecoli-0-1_vs_2-3-5';
            test_start =121;
            cvs1=10;
            mus=32;
		case 21
            file = 'ecoli-0-1_vs_5';
            test_start =121;
            cvs1=10;
            mus=32;
        case 22
            file = 'ecoli-0-1-4-7_vs_5-6';
            test_start =151;
            cvs1=10;
            mus=8;
        case 23
            file = 'ecoli-0-2-3-4_vs_5';
            test_start =101;
            cvs1=10;
            mus=2;
        case 24
            file = 'ecoli-0-2-6-7_vs_3-5';
            test_start =111;
            cvs1=10;
            mus=0.5;
        case 25
            file = 'ecoli-0-3-4-6_vs_5';
            test_start =101;
            cvs1=1e-005;
            mus=8;
        case 26
            file = 'ecoli-0-4-6_vs_5';
            test_start =101;
            cvs1=1;
            mus=2;
        case 27
            file = 'ecoli-0-6-7_vs_3-5';
            test_start =111;
            cvs1=10;
            mus=4;
        case 28
            file = 'ecoli-0-6-7_vs_5';
            test_start =111;
            cvs1=10;
            mus=4;
        case 29
            file = 'ecoli4';
            test_start =151;
            cvs1=10;
            mus=4;
        case 30
            file = 'glass-0-1-4-6_vs_2';
            test_start =101;
            cvs1=10;
            mus=4;
        case 31
            file = 'glass-0-1-5_vs_2';
            test_start =81;
            cvs1=10;
            mus=4;
        case 32
            file = 'glass-0-1-6_vs_2';
            test_start =101;
            cvs1=10;
            mus=4;
		case 33
            file = 'glass-0-1-6_vs_5';
            test_start =91;
            cvs1=10;
            mus=4;
		case 34
            file = 'glass-0-4_vs_5';
            test_start =51;
            cvs1=10;
            mus=4;
		case 35
            file = 'glass-0-6_vs_5';
            test_start =51;
            cvs1=10;
            mus=4;
		case 36
            file = 'glass2';
            test_start =101;
            cvs1=10;
            mus=4;
		case 37
            file = 'led7digit-0-2-4-5-6-7-8-9_vs_1';
            test_start =221;
            cvs1=10;
            mus=4;
		case 38
            file = 'ripley';
            test_start =601;
            cvs1=10;
            mus=4;
		case 39
            file = 'shuttle-c0-vs-c4';
            test_start =901;
            cvs1=10;
            mus=4;
		case 40
            file = 'yeast-0-2-5-6_vs_3-7-8-9';
            test_start =501;
            cvs1=10;
            mus=4;
		case 41
            file = 'yeast-0-2-5-7-9_vs_3-6-8';
            test_start =501;
            cvs1=10;
            mus=4;
		case 42
            file = 'yeast-0-3-5-9_vs_7-8';
            test_start =251;
            cvs1=10;
            mus=4;  
		case 43
            file = 'yeast-0-5-6-7-9_vs_4';
            test_start =251;
            cvs1=10;
            mus=4;  
		case 44
            file = 'yeast-2_vs_4';
            test_start =251;
            cvs1=10;
            mus=4;        
            
		case 45
            file = 'ecoli-0-1-4-6_vs_5';
            test_start =151;
            cvs1=10;
            mus=4;    
		case 46
            file = 'ecoli-0-1-4-7_vs_2-3-5-6 ';
            test_start =151;
            cvs1=10;
            mus=4; 
		case 47
            file = 'ecoli2';
            test_start =151;
            cvs1=10;
            mus=32;
		case 48
            file = 'glass4';
            test_start =151;
            cvs1=10;
            mus=32;
	    case 49
            file = 'ecoli3';
            test_start =151;
            cvs1=10;
            mus=0.5;
        case 50
            file = 'abalone9-18';
            test_start =351;
            cvs1=1e-005;
            mus=8;
		case 51
            file = 'vehicle 1';
            test_start =401;
            cvs1=1;
            mus=2;
		case 52
            file = 'vehicle2';
            test_start =401;
            cvs1=10;
            mus=4;
		case 53
            file = 'shuttle-6_vs_2-3';
            test_start =101;
            cvs1=10;
            mus=4;
		case 54
            file = 'new-thyroid1';
            test_start =101;
            cvs1=10;
            mus=4;
		case 55
            file = 'yeast3';
            test_start =501;
            cvs1=10;
            mus=4;
		case 56
            file = 'yeast1';
            test_start =501;
            cvs1=10;
            mus=4;
		case 57
            file = 'yeast1vs7';
            test_start =201;
            cvs1=10;
            mus=4;
		case 58
            file = 'yeast2vs8';
            test_start =251;
            cvs1=10;
            mus=4;
		case 59
            file = 'ecoli0137vs26';
            test_start =181;
            cvs1=10;
            mus=4;
		case 60
            file = 'yeast5';
            test_start =501;
            cvs1=10;
            mus=4;


        otherwise
            continue;
    end

uvs=0.1;
epsv=[0.1];
mus=[2^-5];
cvs1=[10^-5,10^-4,10^-3,10^-2,10^-1,10^0,10^1,10^2,10^3,10^4];;
cvs2=[10^-5];
cvs3=[10^-5];

%Data file call from folder   
filename = strcat('newd/',file,'.txt');
    A = load(filename);
    [m,n] = size(A);
%define the class level +1 or -1    
    for i=1:m
        if A(i,n)==0
            A(i,n)=-1;
        end
    end
% Dividing the data in training and testing    
test_start=m*0.3;
  [no_input,no_col] = size(A);
    [m,n] = size(A);

    test = A(test_start:m,:);
    train = A(1:test_start-1,:);
    x1 = (train(:,1:no_col-1));
    y1 = train(:,no_col);
	    
    [no_test,no_col] = size(test);
    xtest0 = (test(:,1:no_col-1));
    ytest0 = test(:,no_col);

    %% Universum
    A=[x1 y1];
    [no_input,no_col] = size(A);
   obs = A(:,no_col);   
%     C=A;
    C1= A(1:test_start-1,:);
    A = [];
 B = [];

for i = 1:test_start-1
    if(obs(i) == 1)
        A = [A;C1(i,1:no_col-1)];
    else
        B = [B;C1(i,1:no_col-1)];
    end;
end;
u=ceil(uvs*(test_start-1));
sb1=size(A,1);
sb=size(B,1);
ptb1=sb1/u;
ptb=sb/u;
Au=A(1:ptb1:sb1,:);
Bu=B(1:ptb:sb,:);
di=size(Au,1)-size(Bu,1);
if(di>0)
Bu=[Bu ;Bu(1:abs(di),:)];
elseif(di<0)
Au=[Au ;Au(1:abs(di),:)];
end   
 U=(Au+Bu)/2; 
   

    %Combining all the column in one variable
    A=[x1 y1];    %training data
    A_test=[xtest0,ytest0];    %testing data
 %% initializing crossvalidation variables

    [lengthA,n] = size(A);
    min_err = -10^-10.;
 


  for C1 = 1:length(cvs1)
            c = 10^3%cvs1(randi(10))
        for C2 = 1:length(cvs2)
            c2 = cvs2(C2)
            for C3 = 1:length(cvs3)
            c3 = cvs3(C3)
                 for mv = 1:length(mus)
                    mu = mus(mv)
             
            for  ei = 1:length(epsv)
                    ep = epsv(ei)
                    avgerror = 0;
                    block_size = lengthA/(no_part*1.0);
                    part = 0;
                    t_1 = 0;
                    t_2 = 0;
                    while ceil((part+1) * block_size) <= lengthA
                   %% seprating testing and training datapoints for
                   % crossvalidation
                                t_1 = ceil(part*block_size);
                                t_2 = ceil((part+1)*block_size);
                                B_t = [A(t_1+1 :t_2,:)];
                                Data = [A(1:t_1,:); A(t_2+1:lengthA,:)];
%                                 [m_Data,n_Data]=size(Data);
%                                 sz=ceil(uvs1*(m_Data));
%                                 U1=U(1:sz,:);
                   %% testing and training
                                [accuracy_with_zero,ytest0,classifier,time] = L1TPSVM(Data,B_t,c,mu);
                                avgerror = avgerror + accuracy_with_zero;
                                part = part+1;
                     end

           %% updating optimum c, L
         if avgerror > min_err
               min_err = avgerror;
               min_c1 = c;
%                min_c2 = c2;
%                min_c3 = c3;
%                min_ep = ep;
               min_mu=mu;
         end 
                  [accuracy,ytest,yprediction,time] = NonLLSVMCopy(A,A_test,c,mu);
                  fprintf(file3,'%s\t%g\t%g\t%g\n',file,accuracy,c,mu); 
         
            end
        end
        end
   end
  end
         [accuracy,ytest,yprediction,time] = NonLLSVMCopy(A,A_test,min_c1,min_mu);

 fprintf(file1,'%s\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\n',file,size(A,1),size(A_test,1),accuracy,min_c1,min_mu,time); 
 save(strcat(file,'.mat'),'ytest','yprediction','accuracy','min_c1','min_mu','time');
end
 