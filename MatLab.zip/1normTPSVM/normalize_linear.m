function [res] = normalize_linear(a)
mx = max(a,[],1);
mn = min(a,[],1);
m = size(a,1);
e = ones(m,1);
res = (a-e*mn)./(e*(mx-mn));