function [accuracy,ytest0,predicted_class,train_Time]=L1TPSVM(X,X_test,c,mew)
c1=c;c2 = c; c3=c; c4=c;
[~,d]=size(X);
[m_test,n_test]=size(X_test);

x0=X(:,1:d-1);
y0=X(:,d);
x01 = x0(y0==1,:);
y01 = y0(y0==1,:);

x02 = x0(y0==1,:);
y02 = y0(y0==1,:);

xtest0=X_test(:,1:n_test-1);
ytest0=X_test(:,n_test);

[m1,d]=size(x01);
ed=ones(d,1);
e1=ones(m1,1);
[m2,d]=size(x02);
e2=ones(m2,1);
I1=speye(m1);
I2=speye(m2);
tic

f1=[(ed'+c1*e2'*x02) (ed'-c1*e2'*x02) c2*e1' c1*(e2'*e2)];
AA1=[-x01 x01 -I1 -e1];
BB1=e1*0;
lb1=[zeros(size(f1,2)-1,1);-Inf];

x1 = linprog(f1',AA1,BB1,[],[],lb1);

w1=x1(1:d,:)-x1(d+1:2*d,:);
b1=x1(size(f1,2));
w1 = [w1;b1];

f2=[(ed'-c3*e1'*x01) (ed'+c3*e1'*x01) c4*e2' -c3*(e1'*e1)];
AA2=[x02 -x02 -I1 e2];
BB2=e2*0;
lb2=[zeros(size(f2,2)-1,1);-Inf];

x2 = linprog(f2',AA2,BB2,[],[],lb2);

w2=x2(1:d,:)-x2(d+1:2*d,:);
b2=x2(size(f2,2));
w2 = [w2;b2];

train_Time=toc;
%---------------Testing---------------
no_test=size(X_test,1);
xtest0 = [xtest0 ones(m_test,1)];
% preY=xtest0*w+ b;
d1 = xtest0*w1./norm(w1);
d2 = xtest0*w2./norm(w2);
predicted_class = 2*(d1<d2)-1;
err = sum(predicted_class ~= ytest0);
accuracy=(no_test-err)/(no_test)*100

%%%%%%%Imbalance accuracy
% no_test=m_test;
%   classifier=predicted_class;
%   obs1=ytest0;
%   match = 0.;
% match1=0;
% % classifier = classifier';
% % obs1 = test_data(:,no_col);
% posval=0;
% negval=0;
% %[test_size,n] = size(classifier);
% for i = 1:no_test
%     if(obs1(i)==1)
%     if(classifier(i) == obs1(i))
%         match = match+1;
%     end
%      posval=posval+1;
%     elseif(obs1(i)==-1)
%         if(classifier(i) ~= obs1(i))
%         match1 = match1+1;
%         end
%     negval=negval+1;
%     end
% end
% % if(posval~=0)
% % a_pos=(match/posval)
% % else
% % a_pos=0;
% % end
% % 
% % if(negval~=0)
% % am_neg=(match1/negval)
% % else
% % am_neg=0;
% % end
% 
% % AUC=(1+a_pos-am_neg)/2;
% 
% accuracy=(match/no_test)*100;



% preY=K*beta;
% preY=sign(preY);
% err = sum(preY ~= tstY);
% accuracy=(no_test-err)/(no_test)*100;
% errvec = (preY - tstY);
% err = sqrt((norm(errvec)^2)/size(errvec,1));
% err
% tstY=tstY';   
% preY=preY';
% plot(1:1:m,tstY,'b-',1:1:m,preY,'r-');
% % plot(trnX,trnY,'b.',tstX,preY,'r.');
% legend('Observed','Predicted');
return
end
