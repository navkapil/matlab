function [s]=sigmoid(A,alpha)
%smooth function of derivative of plus(x)
    s=1./(1+exp(-A.*alpha));
end