function nested_circles(num_points, num_circles, inner_rad,ring_width)
% all the circles go from step size 50
%noise 10% ie. 5
% nested_circles(500,4,50,5)
rad = inner_rad;
dataset = zeros(num_circles*num_points,3);
for i=1:num_circles
    r = randn([num_points,1])*ring_width/2 +rad; 
    theta = randn([num_points,1])*pi;
    Px = r.*cos(theta);
    Py = r.*sin(theta);
    dataset((i-1)*num_points+1:i*num_points,:)=[Px Py i*ones(num_points,1)];
    rad=rad+inner_rad;
end
figure;
hold on;
plotstyle={'ro','bo','go','mo','r*','b*','g*','m*'};
for i=1:num_circles
    point = dataset(:,3)==i;
    plot(dataset(point,1),dataset(point,2),plotstyle{i});
end

save('circles.mat','dataset');
end