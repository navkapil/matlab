function [Px1,Px2,Mx1,Mx2] = two_spiral(num_points, noise, inner_rad)
%two_spiral(500, 5, 50)
r1 = (inner_rad:9*inner_rad/(num_points-1):10*inner_rad)';
r1 = r1+randn(num_points,1)*noise;
theta1 = (0:4*pi/(num_points-1):4*pi)';
Px1 = r1.*cos(theta1);
Px2 = r1.*sin(theta1);

r2 = (inner_rad:9*inner_rad/(num_points-1):10*inner_rad)';
r2 = r2+randn(num_points,1)*noise;
theta2 = (0:4*pi/(num_points-1):4*pi)'+pi;
Mx1 = r2.*cos(theta2);
Mx2 = r2.*sin(theta2);

plot(Px1,Px2,'r.',Mx1,Mx2,'g.');
dataset = [[Px1 Px2 ones(num_points,1)];[Mx1 Mx2 -ones(num_points,1)]];
save('twospiral.mat','dataset');
end